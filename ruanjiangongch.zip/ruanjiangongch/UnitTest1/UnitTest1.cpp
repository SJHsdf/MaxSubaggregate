#include "pch.h"
#include "CppUnitTest.h"
#include "../ruanjiangongch/��ͷ.h"
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest1
{
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{

			int sum = 13;
			Assert::AreEqual(sum,ceshi());
		}
	};
}
